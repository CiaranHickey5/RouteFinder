public class MyGraphEdge {
    public MyGraph<?> destNode;
    public int cost;

    public MyGraphEdge(MyGraph<?> destNode,int cost) {
        this.destNode = destNode;
        this.cost = cost;
    }
}
