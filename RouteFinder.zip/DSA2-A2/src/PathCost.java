import java.util.ArrayList;
import java.util.List;

public class PathCost {
    public int pathCost=0;
    public List<MyGraph<?>> pathList=new ArrayList<>();

}
