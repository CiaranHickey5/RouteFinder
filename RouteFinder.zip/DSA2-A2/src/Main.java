import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {

    static Scanner input = new Scanner(System.in);
    static ArrayList<MyGraph <String>> graphList= new ArrayList<>();

    public static void main(String[] args) throws Exception {
        Main m = new Main();


        MyGraph<String> room1 = new MyGraph<>("Room 1");
        graphList.add(room1);
        MyGraph<String> room2 = new MyGraph<>("Room 2");
        graphList.add(room2);
        MyGraph<String> room4 = new MyGraph<>("Room 4");
        graphList.add(room4);
        MyGraph<String> room5 = new MyGraph<>("Room 5");
        graphList.add(room5);
        MyGraph<String> room6 = new MyGraph<>("Room 6");
        graphList.add(room6);
        MyGraph<String> room7 = new MyGraph<>("Room 7");
        graphList.add(room7);
        MyGraph<String> room8 = new MyGraph<>("Room 8");
        graphList.add(room8);
        MyGraph<String> room9 = new MyGraph<>("Room 9");
        graphList.add(room9);
        MyGraph<String> room10 = new MyGraph<>("Room 10");
        graphList.add(room10);
        MyGraph<String> room11 = new MyGraph<>("Room 11");
        graphList.add(room11);
        MyGraph<String> room12 = new MyGraph<>("Room 12");
        graphList.add(room12);
        MyGraph<String> room14 = new MyGraph<>("Room 14");
        graphList.add(room14);
        MyGraph<String> room15 = new MyGraph<>("Room 15");
        graphList.add(room15);
        MyGraph<String> room16 = new MyGraph<>("Room 16");
        graphList.add(room16);
        MyGraph<String> room17 = new MyGraph<>("Room 17");
        graphList.add(room17);
        MyGraph<String> room17a = new MyGraph<>("Room 17a");
        graphList.add(room17a);
        MyGraph<String> room18 = new MyGraph<>("Room 18");
        graphList.add(room18);
        MyGraph<String> room19 = new MyGraph<>("Room 19");
        graphList.add(room19);
        MyGraph<String> room20 = new MyGraph<>("Room 20");
        graphList.add(room20);
        MyGraph<String> room21 = new MyGraph<>("Room 21");
        graphList.add(room21);
        MyGraph<String> room22 = new MyGraph<>("Room 22");
        graphList.add(room22);
        MyGraph<String> room23 = new MyGraph<>("Room 23");
        graphList.add(room23);
        MyGraph<String> room24 = new MyGraph<>("Room 24");
        graphList.add(room24);
        MyGraph<String> room25 = new MyGraph<>("Room 25");
        graphList.add(room25);
        MyGraph<String> room26 = new MyGraph<>("Room 26");
        graphList.add(room26);
        MyGraph<String> room27 = new MyGraph<>("Room 27");
        graphList.add(room27);
        MyGraph<String> room28 = new MyGraph<>("Room 28");
        graphList.add(room28);
        MyGraph<String> room29 = new MyGraph<>("Room 29");
        graphList.add(room29);
        MyGraph<String> room30 = new MyGraph<>("Room 30");
        graphList.add(room30);
        MyGraph<String> room31 = new MyGraph<>("Room 31");
        graphList.add(room31);
        MyGraph<String> room32 = new MyGraph<>("Room 32");
        graphList.add(room32);
        MyGraph<String> room33 = new MyGraph<>("Room 33");
        graphList.add(room33);
        MyGraph<String> room34 = new MyGraph<>("Room 34");
        graphList.add(room34);
        MyGraph<String> room35 = new MyGraph<>("Room 35");
        graphList.add(room35);
        MyGraph<String> room36 = new MyGraph<>("Room 36");
        graphList.add(room36);
        MyGraph<String> room37 = new MyGraph<>("Room 37");
        graphList.add(room37);
        MyGraph<String> room38 = new MyGraph<>("Room 38");
        graphList.add(room38);
        MyGraph<String> room39 = new MyGraph<>("Room 39");
        graphList.add(room39);
        MyGraph<String> room40 = new MyGraph<>("Room 40");
        graphList.add(room40);
        MyGraph<String> room41 = new MyGraph<>("Room 41");
        graphList.add(room41);
        MyGraph<String> room42 = new MyGraph<>("Room 42");
        graphList.add(room42);
        MyGraph<String> room43 = new MyGraph<>("Room 43");
        graphList.add(room42);
        MyGraph<String> room44 = new MyGraph<>("Room 44");
        graphList.add(room44);
        MyGraph<String> room45 = new MyGraph<>("Room 45");
        graphList.add(room45);
        MyGraph<String> room46 = new MyGraph<>("Room 46");
        graphList.add(room46);
        MyGraph<String> room51 = new MyGraph<>("Room 51");
        graphList.add(room51);
        MyGraph<String> room52 = new MyGraph<>("Room 52");
        graphList.add(room52);
        MyGraph<String> room53 = new MyGraph<>("Room 53");
        graphList.add(room53);
        MyGraph<String> room54 = new MyGraph<>("Room 54");
        graphList.add(room54);
        MyGraph<String> room55 = new MyGraph<>("Room 55");
        graphList.add(room55);
        MyGraph<String> room56 = new MyGraph<>("Room 56");
        graphList.add(room56);
        MyGraph<String> room57 = new MyGraph<>("Room 57");
        graphList.add(room57);
        MyGraph<String> room58 = new MyGraph<>("Room 58");
        graphList.add(room58);
        MyGraph<String> room59 = new MyGraph<>("Room 59");
        graphList.add(room59);
        MyGraph<String> room60 = new MyGraph<>("Room 60");
        graphList.add(room60);
        MyGraph<String> room61 = new MyGraph<>("Room 61");
        graphList.add(room61);
        MyGraph<String> room62 = new MyGraph<>("Room 62");
        graphList.add(room62);
        MyGraph<String> room63 = new MyGraph<>("Room 63");
        graphList.add(room63);
        MyGraph<String> room64 = new MyGraph<>("Room 64");
        graphList.add(room64);
        MyGraph<String> room65 = new MyGraph<>("Room 65");
        graphList.add(room65);
        MyGraph<String> room66 = new MyGraph<>("Room 66");
        graphList.add(room66);

        room1.connect(room2,2);
        room2.connect(room4,2);
        room4.connect(room6,2);
        room6.connect(room7,2);
        room7.connect(room8,1);
        room8.connect(room9,2);
        room9.connect(room10,3);
        room4.connect(room5,2);
        room5.connect(room11,2);
        room11.connect(room10,2);
        room11.connect(room14,2);
        room11.connect(room12,2);
        room9.connect(room51,2);
        room51.connect(room52,1);
        room52.connect(room53,1);
        room53.connect(room54,1);
        room54.connect(room55,1);
        room55.connect(room56,1);
        room51.connect(room60,1);
        room60.connect(room59,1);
        room59.connect(room58,1);
        room58.connect(room57,1);
        room59.connect(room53,1);
        room57.connect(room55,1);
        room56.connect(room57,1);
        room60.connect(room61,1);
        room61.connect(room62,1);
        room62.connect(room63,1);
        room63.connect(room64,1);
        room64.connect(room65,1);
        room65.connect(room66,1);
        room63.connect(room59,1);
        room65.connect(room57,1);
        room66.connect(room57,1);
        room9.connect(room16,2);
        room9.connect(room15,2);
        room15.connect(room16,1);
        room16.connect(room17,1);
        room15.connect(room17,1);
        room17.connect(room17a,1);
        room15.connect(room18,2);
        room17a.connect(room18,1);
        room18.connect(room19,2);
        room18.connect(room21,2);
        room18.connect(room22,2);
        room18.connect(room24,2);
        room19.connect(room20,2);
        room20.connect(room21,2);
        room22.connect(room23,2);
        room23.connect(room24,2);
        room24.connect(room25,2);
        room18.connect(room26,2);
        room26.connect(room27,2);
        room27.connect(room28,2);
        room25.connect(room28,2);
        room15.connect(room29,3);
        room28.connect(room29,2);
        room29.connect(room14,3);
        room29.connect(room30,3);
        room30.connect(room31,2);
        room30.connect(room32,3);
        room32.connect(room37,2);
        room32.connect(room33,2);
        room33.connect(room34,2);
        room34.connect(room35,2);
        room36.connect(room37,2);
        room35.connect(room36,2);
        room36.connect(room38,2);
        room38.connect(room39,2);
        room36.connect(room40,2);
        room40.connect(room44,2);
        room34.connect(room41,2);
        room41.connect(room42,2);
        room42.connect(room43,2);
        room43.connect(room44,2);
        room44.connect(room45,2);
        room45.connect(room46,2);

        m.runMenu();
    }

    //This is the menu which is presented to the user when the program is first run
    private int mainMenu(){
        System.out.println("Gallery menu");
        System.out.println("-----------------------------------------");
        System.out.println("Depth-first search methods");
        System.out.println(" 1) Display single path from start to end room using DFS");
        System.out.println(" 2) Display multiple paths from start to end room using DFS");
        System.out.println("-----------------------------------------");
        System.out.println("Breadth-first search methods");
        System.out.println(" 3) Display single path from start to end room using BFS");
        System.out.println("-----------------------------------------");
        System.out.println("Display the cheapest path using Dijkstra's algorithm");
        System.out.println(" 0) Exit");
        System.out.print("Enter option: ");
        int option=input.nextInt();
        return option;
    }

    //Depending on the number that the user enters, a method is called from the run menu
    private void runMenu() throws Exception{
        int option=mainMenu();
        while(option!=0){
            switch (option){
                case 1: findPathDepthFirst();
                    break;
                case 2: findAllPathsDepthFirst();
                    break;
                case 3: findPathBreadthFirst();
                break;
                case 4: findCheapestPathDijkstra();
                break;


                default:
                    System.out.println("Invalid input entered");
            }
            System.out.println("\nPress any key to continue...");
            input.nextLine();
            input.nextLine();
            option = mainMenu();
        }
        System.out.println("Exiting... bye");
        System.exit(0);
    }

    //This method finds a vaccination centre from the name entered
    public MyGraph<String> findRoom(String roomNode){
         for(MyGraph<String> room : graphList) {
             if (room.data.equals(roomNode)) {
                 return room;
             }
         }
        return null;
    }

    public String findRoomNumber(String roomNumber){
        for(MyGraph room : graphList) {
            if (room.data.equals(roomNumber)) {
                return roomNumber;
            }
        }
        return null;
    }

    //Recursive depth-first search of graph (first single path identified returned)
    public void findPathDepthFirst() {
        List<MyGraph<?>> encountered = null;
        //Ask the user to enter the room to start at.
        input.nextLine();
        System.out.println("Please enter the name of the room node you are starting from");
        String nodeStart = input.nextLine();

        //If the room entered is valid we ask them to enter the string of the room to finish at
        MyGraph start = findRoom(nodeStart);
        if (start != null) {

            System.out.println("Please enter the String of the room that you wish to finish at");
            String roomEnd = input.nextLine();
            String end = findRoomNumber(roomEnd);

                System.out.println("Path from room " + start.data +" to room " + end);
                System.out.println("--------------------------------");
                List<MyGraph<?>> path = findPathDepthFirst(start, null, end);
                for (MyGraph<?> n : path) System.out.println(n.data);


        }
    }
    public List<MyGraph<?>> findPathDepthFirst(MyGraph<?> start,List<MyGraph<?>> encountered , String end ) {
        if (end != null) {
            List<MyGraph<?>> result;
            if (start.data.equals(end)) { //Found it
                result = new ArrayList<>(); //Create new list to store the path info (any List implementation could be used)
                result.add(start); //Add the current node as the only/last entry in the path list
                return result; //Return the path list
            }
            if (encountered == null)
                encountered = new ArrayList<>(); //First node so create new (empty) encountered list
            encountered.add(start);
            for (MyGraphEdge adjNode : start.adjList)
                if (!encountered.contains(adjNode.destNode)) {
                    result = findPathDepthFirst(adjNode.destNode, encountered, end);
                    if (result != null) { //Result of the last recursive call contains a path to the solution node
                        result.add(0, start); //Add the current node to the front of the path list
                        return result; //Return the path list
                    }
                }
        }
        return null;
    }

    //Recursive depth-first search of graph (all paths identified returned)
    public void findAllPathsDepthFirst() {
        List<MyGraph<?>> encountered = null;
        //Ask the user to enter the room to start at.
        input.nextLine();
        System.out.println("Please enter the name of the room node you are starting from");
        String nodeStart = input.nextLine();
        //If the room entered is valid we ask them to enter the string of the room to finish at
        MyGraph start = findRoom(nodeStart);
        if (start != null) {
            input.nextLine();
            System.out.println("Please enter the String of the room that you wish to finish at");
            String roomEnd = input.nextLine();
            String end = findRoomNumber(roomEnd);

            System.out.println("All paths from room " + start.data + " to room " + end);
            System.out.println("---------------------------------------------------------------");
            List<List<MyGraph<?>>> allPaths=findAllPathsDepthFirst(start,null,end);
            int pCount=1;
            for(List<MyGraph<?>> p : allPaths) {
                System.out.println("\nPath "+(pCount++)+"\n--------");
                for(MyGraph<?> n : p)
                    System.out.println(n.data);
            }

        }
    }

    public <T> List<List<MyGraph<?>>> findAllPathsDepthFirst(MyGraph<?> start,List<MyGraph<?>> encountered , String end){
        List<List<MyGraph<?>>> result = null, temp2;
        if (end != null) {
            if (start.data.equals(end)) { //Found it

                List<MyGraph<?>> temp = new ArrayList<>(); //Create new single solution path list
                temp.add(start); //Add current node to the new single path list
                result = new ArrayList<>(); //Create new "list of lists" to store path permutations
                result.add(temp); //Add the new single path list to the path permutations list
                return result; //Return the path permutations list
            }
            if (encountered == null)
                encountered = new ArrayList<>(); //First node so create new (empty) encountered list
            encountered.add(start); //Add current node to encountered list
            for (MyGraphEdge adjNode : start.adjList) {
                if (!encountered.contains(adjNode.destNode)) {
                    temp2 = findAllPathsDepthFirst(adjNode.destNode, new ArrayList<>(encountered), end); //Use clone of encountered list
//for recursive call!
                    if (temp2 != null) { //Result of the recursive call contains one or more paths to the solution node
                        for (List<MyGraph<?>> x : temp2) //For each partial path list returned
                            x.add(0, start); //Add the current node to the front of each path list
                        if (result == null)
                            result = temp2; //If this is the first set of solution paths found use it as the result
                        else result.addAll(temp2); //Otherwise append them to the previously found paths
                    }
                }
            }
            return result;
        }
        return null;
    }

    public void findPathBreadthFirst() {
        input.nextLine();
        System.out.println("Please enter the name of the room node you are starting from");
        String nodeStart = input.nextLine();
        //If the room entered is valid we ask them to enter the string of the room to finish at
        MyGraph start = findRoom(nodeStart);
        if (start != null) {
            System.out.println("Please enter the String of the room that you wish to finish at");
            String roomEnd = input.nextLine();
            String end = findRoomNumber(roomEnd);
            if (end != null) {
                System.out.println("The (shortest) breath-first search solution path from room " + start + " to room " + end);
                System.out.println("------------------------------------------");
                List<MyGraph<?>> bfsPath = findPathBreadthFirst(start, end);
                for (MyGraph<?> n : bfsPath) System.out.println(n.data);
            }

        }
    }

    //Interface method to allow just the starting node and the goal node data to match to be specified
    public List<MyGraph<?>> findPathBreadthFirst(MyGraph<?> start, String end){
        List<List<MyGraph<?>>> agenda=new ArrayList<>(); //Agenda comprised of path lists here!
        List<MyGraph<?>> firstAgendaPath=new ArrayList<>(),resultPath;
        firstAgendaPath.add(start);
        agenda.add(firstAgendaPath);
        resultPath=findPathBreadthFirst(agenda,null,end); //Get single BFS path (will be shortest)
        Collections.reverse(resultPath); //Reverse path (currently has the goal node as the first item)
        return resultPath;
    }

    //Agenda list based breadth-first graph search returning a single reversed path (tail recursive)
    public static <T> List<MyGraph<?>> findPathBreadthFirst(List<List<MyGraph<?>>> agenda,
                                                                List<MyGraph<?>> encountered, T lookingfor){
        if(agenda.isEmpty()) return null; //Search failed
        List<MyGraph<?>> nextPath=agenda.remove(0); //Get first item (next path to consider) off agenda
        MyGraph<?> currentNode=nextPath.get(0); //The first item in the next path is the current node
        if(currentNode.data.equals(lookingfor)) return nextPath; //If that's the goal, we've found our path (so return it)
        if(encountered==null) encountered=new ArrayList<>();
        //First node considered in search so create new (empty) encountered list
        encountered.add(currentNode); //Record current node as encountered so it isn't revisited again
        for(MyGraphEdge adjNode : currentNode.adjList) //For each adjacent node
            if(!encountered.contains(adjNode)) { //If it hasn't already been encountered
                List<MyGraph<?>> newPath=new ArrayList<>(nextPath); //Create a new path list as a copy of
//the current/next path
                newPath.add(0,adjNode.destNode); //And add the adjacent node to the front of the new copy
                agenda.add(newPath); //Add the new path to the end of agenda (end->BFS!)
            }
        return findPathBreadthFirst(agenda,encountered,lookingfor); //Tail call
    }

    public void findCheapestPathDijkstra() {
        input.nextLine();
        System.out.println("Please enter the name of the room node you are starting from");
        String nodeStart = input.nextLine();
        //If the room entered is valid we ask them to enter the string of the room to finish at
        MyGraph start = findRoom(nodeStart);
        if (start != null) {
            System.out.println("Please enter the String of the room that you wish to finish at");
            String roomEnd = input.nextLine();
            String end = findRoomNumber(roomEnd);
            if (end != null) {
                System.out.println("The cheapest path using dijkstra's algorithm from room " + start + " to room " + end);
                System.out.println("------------------------------------------");
                PathCost dijkstraPath = findCheapestPathDijkstra(start, end);
                for(MyGraph<?> n : dijkstraPath.pathList)
                    System.out.println(n.data);
                System.out.println("\nThe total path cost is: "+dijkstraPath.pathCost);

            }

        }
    }

    public <T> PathCost findCheapestPathDijkstra(MyGraph<?> start, T end){
        PathCost cp=new PathCost(); //Create result object for cheapest path
        List<MyGraph<?>> encountered=new ArrayList<>(), unencountered=new ArrayList<>(); //Create encountered/unencountered lists
        start.nodeValue=0; //Set the starting node value to zero
        unencountered.add(start); //Add the start node as the only value in the unencountered list to start
        MyGraph<?> currentNode;
        do{ //Loop until unencountered list is empty
            currentNode=unencountered.remove(0); //Get the first unencountered node (sorted list, so will have lowest value)
            encountered.add(currentNode); //Record current node in encountered list
            if(currentNode.data.equals(end)){ //Found goal - assemble path list back to start and return it
                cp.pathList.add(currentNode); //Add the current (goal) node to the result list (only element)
                cp.pathCost=currentNode.nodeValue; //The total cheapest path cost is the node value of the current/goal node
                while(currentNode!=start) { //While we're not back to the start node...
                    boolean foundPrevPathNode=false; //Use a flag to identify when the previous path node is identified
                    for(MyGraph<?> n : encountered) { //For each node in the encountered list...
                        for(MyGraphEdge e : n.adjList) //For each edge from that node...
                            if(e.destNode==currentNode && currentNode.nodeValue-e.cost==n.nodeValue){ //If that edge links to the
//current node and the difference in node values is the cost of the edge -> found path node!
                                cp.pathList.add(0,n); //Add the identified path node to the front of the result list
                                currentNode=n; //Move the currentNode reference back to the identified path node
                                foundPrevPathNode=true; //Set the flag to break the outer loop
                                break; //We've found the correct previous path node and moved the currentNode reference
//back to it so break the inner loop
                            }
                        if(foundPrevPathNode) break; //We've identified the previous path node, so break the inner loop to continue
                    }
                }
//Reset the node values for all nodes to (effectively) infinity so we can search again (leave no footprint!)
                for(MyGraph<?> n : encountered) n.nodeValue=Integer.MAX_VALUE;
                for(MyGraph<?> n : unencountered) n.nodeValue=Integer.MAX_VALUE;
                return cp; //The costed (cheapest) path has been assembled, so return it!
            }
//We're not at the goal node yet, so...
            for(MyGraphEdge e : currentNode.adjList) //For each edge/link from the current node...
                if(!encountered.contains(e.destNode)) { //If the node it leads to has not yet been encountered (i.e. processed)
                    e.destNode.nodeValue=Integer.min(e.destNode.nodeValue, currentNode.nodeValue+e.cost); //Update the node value at the end
                    //of the edge to the minimum of its current value or the total of the current node's value plus the cost of the edge
                    unencountered.add(e.destNode);
                }
            Collections.sort(unencountered,(n1,n2)->n1.nodeValue-n2.nodeValue); //Sort in ascending node value order
        }while(!unencountered.isEmpty());
        return null; //No path found, so return null
    }


}
