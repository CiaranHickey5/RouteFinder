import java.util.ArrayList;
import java.util.List;

public class MyGraph<T> {
    public T data;
    public int nodeValue=Integer.MAX_VALUE;
    //public List<MyGraph<T>> adjList=new ArrayList<>();

    public List<MyGraphEdge> adjList=new ArrayList<>();

    public MyGraph(T data) {
        this.data=data;
    }

    public void connect(MyGraph<T> destNode, int cost) {
//        adjList.add(destNode);
//        destNode.adjList.add(this);
        adjList.add( new MyGraphEdge(destNode,cost) ); //Add new link object to source adjacency list
        destNode.adjList.add( new MyGraphEdge(this,cost) ); //Add new link object to destination adjacency list

    }
}


